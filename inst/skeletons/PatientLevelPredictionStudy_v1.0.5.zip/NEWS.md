SkeletonPredictionStudy 1.0.2
======================
  - Cleaned r package check 



SkeletonPredictionStudy 1.0.1
======================
  - Using CohortGenerator package for cohort creation


SkeletonPredictionStudy 1.0.0
======================
  - Updated package for PLP version 5 as json settings changed


SkeletonPredictionStudy 0.0.8
======================
  - Added ability to save models as json for validation

SkeletonPredictionStudy 0.0.1
======================
  - A skeleton package that can be used to develop studies to train and internally validate patient-level prediction models
